# 美容室棚卸管理システム

美容室の在庫・棚卸を管理するWebアプリケーションです。

## 機能

- スタッフ管理
- 商品管理（ディーラー・カテゴリー別）
- 使用記録（クイック入力・まとめて入力対応）
- 入荷記録
- 棚卸入力（予想在庫自動計算）
- ディーラー別集計

## セットアップ

### 環境変数

`.env.local` ファイルに以下を設定：

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 開発サーバー起動

```bash
npm install
npm run dev
```

## 技術スタック

- Next.js 14
- React 18
- Supabase（データベース）
